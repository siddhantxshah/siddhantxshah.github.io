var uiApp = angular.module('uiApp',['ngRoute']);

uiApp.config(function($routeProvider){
  $routeProvider
  .when('/',{
    templateUrl: 'Views/homeView.html'
  })
  .when("/content",{
      templateUrl: 'Views/ContentView/ContentView.html'
  })
  .when('/assignmentsHtml',{
	  templateUrl: 'Views/assignmentsHomeView.html'
  })
  .when('/assignmentsCss',{
	  templateUrl: 'Views/assignmentsCSSView.html'
  })
  .when('/assignmentsJS',{
	  templateUrl: 'Views/assignmentsJSView.html'
  })
  .when('/assignmentsJquery',{
	  templateUrl: 'Views/assignmentsJqueryView.html'
  })
  .when('/assignmentsAngular',{
	  templateUrl: 'Views/assignmentsAngularView.html'
  })
  .when('/interview',{
	  templateUrl: 'Views/interviewQuestionsView.html'
  })
  .when('/books',{
	  templateUrl: 'Views/booksView.html'
  })
  .otherwise({
	  redirectTo: '/'
  });
  
  




});
